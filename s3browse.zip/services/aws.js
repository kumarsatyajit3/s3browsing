var AWS = require("aws-sdk");
var s3 = new AWS.S3({
    accessKeyId: 'AKIAUUJPLRJXNMFZQ3R3',
    secretAccessKey: '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',
});

class AwsHelper {
    constructor() {
    }

    async listBuckets() {
        return new Promise((resolve, reject) => {
            s3.listBuckets(function (err, data) {
                if (err) {
                    reject(err);
                }
                else {
                    resolve((data.Buckets || []).map(i => new Folder(i.Name)).sort((a, b) => a.name - b.name));
                }
            });
        });
    }

    async listObjects(bucket, prefix) {
        return new Promise((resolve, reject) => {
            const params = {
                Bucket: bucket,
                Delimiter: '/',
                MaxKeys: 2000
            };

            if (prefix) {
                params.Prefix = prefix.replace(/^\/*(.*?)\/*$/, '$1') + '/';
            }

            s3.listObjects(params, function (err, data) {
                if (err) {
                    reject(err);
                }
                else {
                    console.log(data);
                    const folders = (data.CommonPrefixes || []).map(i => new Folder(i.Prefix.replace(params.Prefix, '').replace(/^\/*(.*?)\/*$/, '$1'))).sort((a, b) => a.name - b.name);
                    const files = (data.Contents || []).map(i => new File(i.Key.replace(params.Prefix, ''), i.Size, i.LastModified)).sort((a, b) => a.name - b.name);
                    resolve(folders.concat(files));
                }
            });
        });
    }

    async downloadObject(bucket, file) {
        return s3.getObject({ Bucket: bucket, Key: file }).createReadStream();
    }
}

class Folder {
    constructor(name, type = 'folder') {
        this.name = name;
        this.type = type;
    }
}

class File extends Folder {
    constructor(name, size, lastModifiedAt) {
        super(name, 'file');
        this.size = size;
        this.lastModifiedAt = lastModifiedAt;
    }
}

module.exports = AwsHelper;