var express = require('express');
var router = express.Router();
var AwsHelper = require('../services/aws');
const aws = new AwsHelper();

function _trim(str) {
  return str.replace(/^\/*(.*?)\/*$/, '$1')
}

/* GET home page. */
router.get('/', async function (req, res, next) {
  try {
    const entries = await aws.listBuckets();
    res.render('index', { entries });
  } catch (e) {
    next(e);
  }
});

router.get('/:apiPath*', async function (req, res, next) {
  try {
    let fullPath;
    let isApi = false;
    if (req.params.apiPath === 'api') {
      isApi = true;
      fullPath = _trim(req.params[0]);
    } else {
      fullPath = req.params.apiPath + (req.params[0] ? ('/' + _trim(req.params[0])) : '');
    }

    const parts = fullPath.split('/');
    const previous = fullPath.substring(0, fullPath.lastIndexOf('/') + 1);

    if (req.query.download === 'true') {
      return (await aws.downloadObject(parts.shift(), parts.join('/'))).pipe(res);
    }

    let entries;
    if (fullPath === "" || fullPath === "/") {
      entries = await aws.listBuckets();
    } else {
      entries = await aws.listObjects(parts.shift(), parts.join('/'));
    }

    if (isApi) {
      res.json(entries);
    } else {
      res.render('index', { entries, path: '/' + fullPath, previous: '/' + previous });
    }

  } catch (e) {
    next(e);
  }
});

module.exports = router;
